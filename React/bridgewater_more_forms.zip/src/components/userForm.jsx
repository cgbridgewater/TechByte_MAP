import React, { useState } from  'react';
    
const UserForm = (props) => {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState(""); 
    const [confirmPassword, setConfirmPassword] = useState("");  
    const [hasBeenSubmitted, setHasBeenSubmitted] = useState(false);
    const [firstnameError, setFirstnameError] = useState("");
    const [lastnameError, setLastnameError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    const isBlank = firstname === "" || lastname === "" || email === "" || password === "" || confirmPassword === ""
    const hasError = firstnameError !==""|| lastnameError !== "" || emailError !== "" || passwordError !== "" || confirmPasswordError !== ""
    const canSubmit = hasError || isBlank

    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstname,lastname, email, password,confirmPassword };
        console.log("Welcome", newUser);
        setFirstname("");
        setLastname("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
        setHasBeenSubmitted( true );
    };

    const handleFirstname = (e) => {
        setFirstname(e.target.value);
        if(e.target.value.length < 2) {
            setFirstnameError("First name must be 2 characters or longer!");
        } else {
            // an empty string is considered a "falsy" value
            setFirstnameError("");
            // setBlankForm("");
        }
    }

    const handleLastname = (e) => {
        setLastname(e.target.value);
        if(e.target.value.length < 2) {
            setLastnameError("Last name must be 2 characters or longer!");
        } else {
            // an empty string is considered a "falsy" value
            setLastnameError("");
            // setBlankForm("")
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value);
        if(e.target.value.length < 5) {
            setEmailError("Email must be 5 characters or longer!");
        } else {
            // an empty string is considered a "falsy" value
            setEmailError("");
            // setBlankForm("")
        }
    }

    const handlePassword = (e) => {
        setPassword(e.target.value);
        if(e.target.value.length < 8) {
            setPasswordError("Password must be 8 characters or longer!");
        }else {
            // an empty string is considered a "falsy" value
            setPasswordError("");
        }
        if(e.target.value !== confirmPassword) {
            setConfirmPasswordError("Passwords must match!")
        }else {
            setConfirmPasswordError("");
        }
    }

    const handleConfirmPassword = (e) => {
        setConfirmPassword(e.target.value);
        if(e.target.value !== password) {
            setConfirmPasswordError("Passwords must match!")
        }else {
            setConfirmPasswordError("");
        }
    }

    return(
        <div>
            {/* <div className='Alignment'>
                <form>
                    <input className='Reset' type="submit" value="Reset Form" />
                </form>
            </div> */}
            <div className='Alignment'>
                <div className='Container'>
                        <form className='Form' onSubmit={ createUser }>
                        {
                            hasBeenSubmitted ? 
                            <h3>Thank you for submitting the form!</h3> :
                            <h3>Welcome, please submit the form.</h3> 
                        }
                        {
                            firstnameError ?
                            <p>{ firstnameError }</p> :
                            ''
                        }
                        {
                            lastnameError ?
                            <p>{ lastnameError }</p> :
                            ''
                        }
                        {
                            emailError ?
                            <p>{ emailError }</p> :
                            ''
                        }
                        {
                            passwordError ?
                            <p>{ passwordError }</p> :
                            ''
                        }
                        {
                            confirmPasswordError ?
                            <p>{ confirmPasswordError }</p> :
                            ''
                        }
                            <div>
                                <label htmlFor='firstname'>Firstname: </label> 
                                <input type="text" value={firstname} onChange={ handleFirstname } />
                            </div>
                            <div>
                                <label htmlFor='lastname'>Lastname: </label> 
                                <input type="text" value={lastname} onChange={ handleLastname } />
                            </div>
                            <div>
                                <label htmlFor='email'>Email Address: </label> 
                                <input type="text" value={email} onChange={ handleEmail} />
                            </div>
                            <div>
                                <label htmlFor='password'>Password: </label>
                                <input type="password" value={password} onChange={ handlePassword } />
                            </div>
                            <div>
                                <label htmlFor='confirmpassword'>Confirm Password: </label>
                                <input type="password" value={confirmPassword} onChange={ handleConfirmPassword } />
                            </div>
                            {
                                // firstnameError||lastnameError||emailError||passwordError||confirmPasswordError|| blankForm ?
                                // isBlank||hasError ?
                                canSubmit ?
                                <input className='btn1' type="submit" value="Complete Form!" disabled /> : 
                                <input className='btn2' type="submit" value="Create User" />
                            }
                        </form>
                    <hr />
                    <div>
                    <p className='Text'>First Name: {firstname}</p>
                    <p className='Text'>Last Name: {lastname}</p>
                    <p className='Text'>Email: {email}</p>
                    <p className='Text'>Password: {password}</p>
                    <p className='Text'>Confirm Password: {confirmPassword}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};
    
export default UserForm;
