import './App.css';
import UserForm from './components/userForm';

function App() {
  return (
    <div className="App">
      <UserForm/>
    </div>
  );
}

export default App;
